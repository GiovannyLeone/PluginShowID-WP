<?php
/**
 * @package GET ID User
 * @version 1.0
 */
/*
Plugin Name: GET ID User - Task - WPMU DEV
Plugin URI: http://wordpress.org/
Description: This a plugin that get the ID of Users for show to display in screen
Author: Giovanny Leone
Version: 1.0
Author URI: http://giovannyleone.com/
*/
?>

<?php


if ( ! function_exists( 'tutsup_session_start' ) ) {

    function tutsup_session_start() {

        if (is_user_logged_in()) {

            $user = wp_get_current_user();

            $IdUserDisplay = $user->{"data"}->display_name;

            ?>

            <!DOCTYPE html>
            <body>

            <span style="background: #FFF; position: fixed; right: 10px; top: 50px; padding: 5px 10px;">Hello, <?=$IdUserDisplay?></span>
                
            </body>
            </html>

            <?php
        }
    }

    add_action( 'init', 'tutsup_session_start' );
}
?>
